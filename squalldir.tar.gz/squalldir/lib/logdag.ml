
(** The first input signature of the functor {!Logdag.Make} specifying various paramters. *)
module type PARAM =
  sig
    val dbname : string (** File name of the Dbm database. Files {i dbname}[.dir] and {i dbname}[.pag] are created if necessary. *)
    val max_mem : float  (** Number of bytes beyond which nodes are removed from memory. *)
    val node_chunk : int  (** Number of nodes that are removed from memory when more than [max_mem] is used. *) 
    val log_file : string option  (** Optional filename for printing a log of internal messages. *)
  end

(** The second input signature of the functor {!Logdag.Make} specifying the logic. *)
module type LOG =
  sig
    type t  (** Abstract type of formulas. *)
    val top : unit -> t  (** Most general formula. *)
    val entails : t -> t -> bool  (** Entailment relation {e is more specific than} of the logic. *)
    val parse : Syntax.t_stream -> t  (** Parsing of formulas from token streams. *)
    val print : t -> Syntax.t_list  (** Printing of formulas to token lists. *)
    val gen : t -> t -> t list -> t list  (** Dichotomic operator for generating new features. *)
    val simpl : t -> t Stream.t  (** Simplifications of a formula. *)
  end

(** The signature of implementations of logical diagrams. *)
module type T =
  sig
    module Log : LOG
    (** The logic module passed as a parameter. *)

    val some_log : bool
    (** True if a log file is open. *)

    val log_fmt : Format.formatter
    (** The formatter associated to the log file when it exists. *)

    val db : Dbm.t
    (** The database used for persistency and swapping. *)

    type nid = int
    (** Type of node ids. This type is also used for identifying objects: the id of an object is the id of its description node. *)

    val nil : nid
    (** Nil id referencing no node. *)

    val top : nid
    (** Id of the most general node. *)

(*
    (** Module for the representation of extents (sets of objects). *)
    module Ext :
      sig
        type t  (** Abstract type of extents. *)
        val empty : t  (** The empty extent. *)
        val is_empty : t -> bool  (** [is_empty ext] tests whether [ext] is empty. *)
        val cardinal : t -> int  (** [cardinal ext] returns the size of the extent [ext]. *)
        val mem : nid -> t -> bool  (** [mem o ext] tests whether [o] belongs to [ext]. *)
        val contains : t -> t -> bool  (** [contains ext1 ext2] tests whether [ext1] contains [ext2]. *)
        val add : nid -> t -> t  (** [add o ext] returns the addition of [o] to [ext]. *)
        val remove : nid -> t -> t  (** [remove o ext] returns the removal of [o] from [ext]. *)
        val union : t -> t -> t  (** [union ext1 ext2] returns the set union of [ext1] and [ext2]. *)
        val union_r : t list -> t  (** [union_r exts] returns the union of all extents in [exts]. *)
        val inter : t -> t -> t  (** [inter ext1 ext2] returns the set intersection of [ext1] and [ext2]. *)
        val inter_r : t list -> t  (** [inter_r exts] returns the intersection of all extents in [exts].
                                       @raise Invalid_argument if [exts] is the empty list. *)
        val subtract : t -> t -> t  (** [subtract ext1 ext2] returns the set subtraction of [ext1] and [ext2]. *)
        val inter_difsym : t -> t -> t * t * t
          (** [inter_difsym ext1 ext2] returns the extent triplet [(subtract ext1 ext2, inter ext1 ext2, subtract ext2 ext1)]. *)
        val iter : (nid -> unit) -> t -> unit
          (** Iteration on the objects of an extent (see [List.iter]). Objects visited from low ids to high ids. *)
        val fold_left : ('a -> nid -> 'a) -> 'a -> t -> 'a
          (** Folding on an extent from low ids to high ids (see List.fold_left). *)
        val fold_right : (nid -> 'a -> 'a) -> t -> 'a -> 'a
          (** Folding on an extent from high ids to low ids (see List.fold_right). *)
      end
*)

    type node
    (** Abstract type of nodes.

       {e Warning}: values of this type are relevant at the time they are
	retrieved, but are not guarenteed to remain consistent after changes are
	made. *)

    val feat : node -> Log.t
    (** [feat node] gets the formula label of [node]. *)

    val ext : node -> Ext.t
    (** [ext node] gets the extent label of [node]. *)

    val inf : node -> nid LSet.t
    (** [inf node] gets the inferior (more specific) neighbours of [node]. *)

    val sup : node -> nid LSet.t
    (** [sup node] gets the superior (more general) neighbours of [node]. *)

    val is_obj : node -> bool
    (** [is_obj node] test whether [node] is labeled by an object. *)

    val get : nid -> node
    (** [get nid] retrieves a node from its id [nid]. If the node is not yet in memory, it is loaded from the database.
        @raise Not_found when the node [nid] does not exist in the diagram. *)

    val insert : Log.t -> bool -> nid * bool
    (** [insert f obj] returns the node id whose formula label is
	logically equivalent to [f]. If such a node does not yet exist in the
	diagram, it is inserted and the second result is [true]; otherwise the second result is [false]. 
        If [obj] is true, then a new object is
	associated to this node, and extents of existing nodes are updated
	accordingly. *)

    val remove : nid -> unit
    (** [remove nid] removes the node identified by [nid] from the diagram (both in memory and the database). *)

    val fold : (nid * node Lazy.t -> 'a -> 'a * nid list) -> nid * node Lazy.t -> 'a -> 'a
    (** [fold f_next (nid,node) e] computes a result through a traversal of
	the diagram. The starting node is specified by [(nid,node)], where
	[node] is the lazy evaluation of [get nid]. The application [f_next (nid,node)
	res] to the current node [(nid,node)] and the current result [res]
	returns a pair [(res',next_nids)], where [res'] is the new result, and
	[next_nids] are the ids of the next nodes to be visited. The traversal
	order is not specified, but each node is ensured to be visited at most
	once. *)

    val first : pred_next:(bool -> nid * node Lazy.t -> 'a option * nid list) -> start:(nid * node Lazy.t) -> 'a list
    (** [first ~pred_next ~start:(nid,node)] looks for the first nodes encountered in
	a traversal of the diagram, and satisfying some condition {e
	pred}. The traversal is defined similarly to [fold] (starting point,
	and next nodes). The first result of an application of [pred_next] is
	[None] if {e pred} is not satisfied, and [Some] {i v} otherwise, {i v}
	being the value returned as a result instead of the node itself. The
	first parameter can be used for optimization as, when it is false,
	[None] can be returned in all cases. *)

    val last : pred_next:(nid * node Lazy.t -> 'a option * nid list) -> start:(nid * node Lazy.t) -> 'a list
    (** [last ~pred_next ~start:(nid,node)] looks for the last nodes encountered in
	a traversal of the diagram, and satisfying some condition {e
	pred}. The traversal is defined similarly to [fold] (starting point,
	and next nodes). The first result of an application of [pred_next] is
	[None] if {e pred} is not satisfied, and [Some] {i v} otherwise, {i v}
	being the value returned as a result instead of the node itself. *)

    val glbs : pred:(nid * node Lazy.t -> bool) -> (nid * node Lazy.t) list -> (nid * node Lazy.t) list
    (** [glbs ~pred nodes] returns the {e glbs} (greatest lower bounds) of the nodes [nodes] among the nodes satisfying [pred]. *)

    val lubs : pred:(nid * node Lazy.t -> int -> 'a option) -> suppmin:int -> (nid * node Lazy.t) list -> 'a list
    (** [lubs ~pred ~suppmin nodes] returns the [suppmin]-approximate {e lubs}
	(least upper bounds) of the nodes [nodes] among the nodes satisfying
	[pred]. A node is a [suppmin]-approximate lub if it has at least
	[suppmin] more specific nodes in [nodes]. The second argument of
	[pred] is the support of the node (number of more specific nodes in
	[nodes]). *)

  end

module Make (Param : PARAM) (Log : LOG) : T =
  struct
    module Log = Log

    open Format

    let some_log = match Param.log_file with None -> false | Some _ -> true
    let log_fmt = match Param.log_file with None -> Format.err_formatter | Some name -> formatter_of_out_channel (open_out name)

    type nid = int

    module Nval =
      struct
        type t = float
        let init () = Common.utime ()
        let update v = Common.prof "Logdag.Nval.update" (fun () -> Common.utime ())
        let better v1 v2 = v1 >= v2
      end

    type node = {
	mutable feat : Log.t;  (* formula describing the node, and description of local object if some *)
	mutable ext : Ext.t;  (* object idents of the extent *)
	mutable sup : nid LSet.t;  (* list of parent nodes *)
	mutable inf : nid LSet.t;  (* list of child nodes *)
        mutable v : Nval.t  (* value w.r.t. swapping *)
      }

    let nil = 0
    let node_nil = {
        feat = Log.top ();
        ext = Ext.empty;
        inf = LSet.empty ();
        sup = LSet.empty ();
        v = Nval.init ()
      }

    let top = 1

    let db = Dbm.opendbm Param.dbname [Dbm.Dbm_create; Dbm.Dbm_rdwr] 0o664
    let _ = at_exit (fun () -> Dbm.close db)

    let db_mod : Dbm.t Cache.db_mod = {
        Cache.find = Dbm.find;
        Cache.replace = Dbm.replace;
        Cache.remove = Dbm.remove
      }

    let cache_cpt = Cache.create db_mod db "cpt" 1
    let _ =
      if not (Cache.mem cache_cpt 0)
      then Cache.add cache_cpt 0 (ref (top+1))

    let cpt () = Cache.get cache_cpt 0


    let cache_nid = Cache.create db_mod db "nid" Param.node_chunk
    let _ =
      if not (Cache.mem cache_nid top)
      then Cache.add cache_nid top node_nil

    let get_worst_chunk () =
      let rec insert x =
        function
        | [] -> [x]
        | y::ys ->
           if Nval.better x y
           then x::y::ys
           else y::insert x ys in
      let _, worst_chunk =
        Cache.fold
          (fun nid node (n,l) ->
             let n', l' = n+1, insert (node.v,nid) l in
             if n' <= Param.node_chunk
             then n', l'
             else n, List.tl l')
          cache_nid (0,[]) in
      List.map snd worst_chunk

    let unget_cpt = ref 0

    let unget_chunk () = Common.prof "Logdag.unget_chunk" (fun () ->
      if (unget_cpt := !unget_cpt+1 mod Param.node_chunk; !unget_cpt = 0) & Common.heap_size () > Param.max_mem
      then begin
        if some_log then pp_print_string log_fmt "Logdag: swapping nodes on disk\n";
        let keys = get_worst_chunk () in
        List.iter (Cache.unget cache_nid) keys;
        Gc.major () end)

    let get nid = Common.prof "Logdag.get" (fun () ->
      unget_chunk ();
      let node = Cache.get cache_nid nid in
      node.v <- Nval.update node.v;
      node)

    let create node =
      unget_chunk ();
      let cpt = cpt () in
      let nid = !cpt in
      incr cpt;
      Cache.add cache_nid nid node;
      nid

    let delete nid = Cache.remove cache_nid nid


    let feat node = node.feat

    let ext node = node.ext

    let inf node = node.inf

    let sup node = node.sup

    let is_obj node = LSet.is_empty node.inf & node.ext <> Ext.empty

    let rec fold : (nid * node Lazy.t -> 'a -> 'a * nid list) -> nid * node Lazy.t -> 'a -> 'a =
      fun f_next (nid,node) init ->
        let m = Array.make !(cpt ()) `Unknown
        in fold2 m f_next (nid,node) init
    and fold2 m f_next (nid,node) init =
      if m.(nid) = `Unknown
      then begin
        m.(nid) <- `Good;
        let res0, nids = f_next (nid,node) init in
        List.fold_left
	  (fun res n -> fold2 m f_next (n,lazy (get n)) res)
	  res0
	  nids end
      else init

    let rec first : pred_next:(bool -> nid * node Lazy.t -> 'a option * nid list) -> start:(nid * node Lazy.t) -> 'a list =
      fun ~pred_next ~start ->
	let m = Array.make !(cpt ()) `Unknown
	in List.map snd (
          List.fold_left
	    (fun res nid -> first2 m pred_next (nid,lazy (get nid)) true res)
	    [] (snd (pred_next false start)))
    and first2 m pred_next (nid,node) above res =
	if m.(nid) = `Unknown then
	  let x, nids = pred_next above (nid,node) in
	  let good = above & (x <> None) in
	  m.(nid) <- if good then `Good else `Bad;
	  List.fold_left
	    (fun res n -> first2 m pred_next (n,lazy (get n)) (above & not good) res)
	    (match x with None -> res | Some v -> if good then ((nid, v)::res) else res)
	    nids
	else if m.(nid) = `Good & not above then begin
	  m.(nid) <- `Bad;
	  List.filter (fun (n,v) -> n != nid) res end 
	else res

    let rec last : pred_next:(nid * node Lazy.t -> 'a option * nid list) -> start:(nid * node Lazy.t) -> 'a list =
      fun ~pred_next ~start ->
	let m = Array.make !(cpt ()) `Unknown in
	snd (new_last m pred_next start [])
    and new_last m pred_next (nid,node) res =
	let x, nids = pred_next (nid,node) in
	let last, res1 = List.fold_left
	    (fun (last,res) n ->
	      if m.(n) = `Good then (false,res) (* node is not a last one *)
	      else if m.(n) = `Bad then (last,res) (* node may be a last one *)
	      else (* m.(n) = `Unknown *)
		let last',res' = new_last m pred_next (n,lazy (get n)) res in
		last & last', res')
	    (true,res)
	    nids in
	if not last
	then begin m.(nid) <- `Good; (false,res1) end
	else match x with
	| None -> begin m.(nid) <- `Bad; (true,res1) end
	| Some v -> begin m.(nid) <- `Good; (false,v::res1) end

    let glbs : pred:(nid * node Lazy.t -> bool) -> (nid * node Lazy.t) list -> (nid * node Lazy.t) list =
      fun ~pred -> function
	| [] -> [(top,lazy (get top))]
	| [nidnode] when pred nidnode -> [nidnode]
	| nidnodes ->
	    let m = Array.make !(cpt ()) 0 in
	    let lnodes = List.length nidnodes in
	    List.iter
	      (fun (nid,node) ->
		fold (fun (n,nd) res -> m.(n) <- m.(n)+1; (), (Lazy.force nd).inf) (nid,node) ())
	      nidnodes;
	    first
	      (fun above (nid,node) ->
		(if above & m.(nid) >= lnodes & pred (nid,node) then Some (nid,node) else None), (Lazy.force node).inf)
	      (nil, lazy {node_nil with inf = List.map fst nidnodes})

    let rec lubs : pred:(nid * node Lazy.t -> int -> 'a option) -> suppmin:int -> (nid * node Lazy.t) list -> 'a list =
      fun ~pred ~suppmin -> function
	| [] -> raise (Invalid_argument "LogDag.Make.lubs : the list is empty") 
	| nidnodes -> Common.prof "Logdag.lubs" (fun () ->
	    let m = Array.make !(cpt ()) 0 in
	    let l = List.length nidnodes in
	    let supp = min suppmin l in
	    List.iter
	      (fun (nid,node) ->
		fold (fun (n,nd) res -> m.(n) <- m.(n)+1; (), (Lazy.force nd).sup) (nid,node) ())
	      (if supp=l then List.tl nidnodes else nidnodes);
            let smin = if supp=l then supp-1 else supp in
	    first
	      (fun _ (nid,node) ->
                let s = m.(nid) in
		(if s >= smin then pred (nid,node) s else None),
		(Lazy.force node).sup)
	      (if supp=l then (List.hd nidnodes) else (nil,lazy {node_nil with sup = List.map fst nidnodes})))


    let locate : Log.t -> bool -> nid * node =
      fun feat obj ->
	let sup =
	  last
	    ~pred_next:(fun (nid,node) ->
	       if not (is_obj (Lazy.force node)) & Log.entails feat (Lazy.force node).feat
	       then Some (nid,node), (Lazy.force node).inf
	       else None, [])
	    ~start:(top,lazy (get top)) in
	match sup with
	| [(nid,node)] when not obj & Log.entails (Lazy.force node).feat feat ->
	     (Lazy.force node).feat <- feat;  (* the old formula is replaced by the new equivalent one *)
	     nid, Lazy.force node  (* the searched node already exists *)
	| nodes ->  (* the searched node must be inserted *)
	     let inf, ext =
	       if obj
               then LSet.empty (), Ext.empty
               else
                 let inf = glbs (fun (nid,node) -> Log.entails (Lazy.force node).feat feat) nodes in
                 inf, List.fold_left Ext.union Ext.empty (List.map (fun (nid,node) -> (Lazy.force node).ext) inf) in
	     let new_node = {
		feat = feat;
		ext = ext;
		sup = LSet.of_list (List.map fst sup);
		inf = LSet.of_list (List.map fst inf);
                v = Nval.init ()} in
	     nil, new_node

    let connect : nid -> node -> bool -> unit =
      fun nid node obj ->
	List.iter
	  (fun n ->
             let nd = get n in
             nd.inf <- LSet.add nid (LSet.subtract nd.inf node.inf))
	  node.sup;
	List.iter
	  (fun n ->
             let nd = get n in
             nd.sup <- LSet.add nid (LSet.subtract nd.sup node.sup))
	  node.inf;
        if obj
        then
	  fold
	    (fun (n,nd) () ->
               let nd_val = Lazy.force nd in
               nd_val.ext <- Ext.add nid nd_val.ext; (), nd_val.sup)
	    (nid,lazy node)
	    ()

    let insert feat obj = Common.prof "Logdag.insert" (fun () ->
      let nid, node = locate feat obj in
      if nid = nil
      then begin
        let nid = create node in
        connect nid node obj;
        nid, true end
      else begin
        nid, false end)

    let rec disconnect nid =
      let node = get nid in
      if is_obj node
      then
	fold
	  (fun (n,nd) () ->
             let nd_val = Lazy.force nd in
             nd_val.ext <- Ext.remove nid nd_val.ext; (), nd_val.sup)
	  (nid,lazy node)
	  ();
      List.iter (fun n -> let nd = get n in nd.inf <- LSet.remove nid nd.inf) node.sup;
      List.iter (fun n -> let nd = get n in nd.sup <- LSet.remove nid nd.sup) node.inf;
      let mup = Array.make !(cpt ()) false in
      fold
        (fun (n,nd) () -> (mup.(n) <- true), (Lazy.force nd).sup)
        (nil,lazy {node_nil with sup = node.inf})
        ();
      let mdown = Array.make !(cpt ()) false in
      let tbl = Hashtbl.create (2 * LSet.cardinal node.inf) in
      List.iter (fun n -> Hashtbl.add tbl n node.sup) node.inf;
      List.iter
	(fun n ->
           let nd = get n in
           List.iter (fun n' -> mdown.(n') <- false) node.inf;
           fold
             (fun (n',nd') () -> (mdown.(n') <- true), if mup.(n') then (Lazy.force nd').inf else [])
             (n,lazy (get n))
             ();
           let inf_old, inf_new = List.partition (fun n' -> mdown.(n')) node.inf in
	   nd.inf <- LSet.union nd.inf inf_new;
           List.iter (fun n' -> Hashtbl.replace tbl n' (LSet.remove n (Hashtbl.find tbl n'))) inf_old)
        node.sup;
      List.iter
        (fun n ->
           let nd = get n in
           nd.sup <- LSet.union nd.sup (Hashtbl.find tbl n))
        node.inf

    let remove nid =
      if nid <> top
      then begin
        try disconnect nid with Not_found -> ();
        delete nid end

  end
