(** Tokens and utility functions. *)

exception Eof

type t =
  | Quote | DoubleQuote | BackQuote
  | Comma | Colon | SemiColon | Dot | Interro | Exclam
  | LeftPar | RightPar | LeftAcc | RightAcc | LeftBra | RightBra
  | Nat of int | MinusNat of int
  | Char of char
  | String of string
  | Symbol of string
  | PP_tilda | PP_space | PP_cut | PP_break of int * int | PP_newline

(* predicate filtering PP_* tokens *)
let is_PP = function PP_tilda | PP_space | PP_cut | PP_break _ | PP_newline -> true | _ -> false

(* predicate for testing whether a symbol needs quotes *)
let symbol_needs_quotes s =
  let is_ident = Str.string_match (Str.regexp "^[A-Za-z_][A-Za-z0-9_]*$") s 0 in
  let is_op = Str.string_match (Str.regexp "^[-~@#$%^&*+=|\\/><]+$") s 0 in
  not (is_ident || is_op)
